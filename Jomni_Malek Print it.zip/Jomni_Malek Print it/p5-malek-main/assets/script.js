const leftArrow = document.querySelector(".arrow_left");
const rightArrow = document.querySelector(".arrow_right");
const imgBanner = document.querySelector(".banner-img");
const pBanner = document.querySelector("#banner p");
const dotsBanner = document.querySelector(".dots");

let index = 0;

const slides = [
  {
    image: "slide1.jpg",
    tagLine: "Impressions tous formats <span>en boutique et en ligne</span>",
  },
  {
    image: "slide2.jpg",
    tagLine:
      "Tirages haute définition grand format <span>pour vos bureaux et events</span>",
  },
  {
    image: "slide3.jpg",
    tagLine: "Grand choix de couleurs <span>de CMJN aux pantones</span>",
  },
  {
    image: "slide4.png",
    tagLine: "Autocollants <span>avec découpe laser sur mesure</span>",
  },
];

slides.forEach((_elem, i) => {
  const dot = document.createElement("span");
  dot.classList.add("dot");

  if (i === index) {
    dot.classList.add("dot_selected");
  }

  dot.addEventListener("click", function () {
    index = i;
    imgBanner.src = "./assets/images/slideshow/" + slides[index].image;
    pBanner.innerHTML = slides[index].tagLine;

    colorDotElement();
  });

  dotsBanner.appendChild(dot);
});

function colorDotElement() {
  const dots = document.querySelectorAll(".dot");
  dots.forEach((dot, i) => {
    dot.classList.remove("dot_selected");
    if (i === index) {
      dot.classList.add("dot_selected");
    }
  });
}

rightArrow.addEventListener("click", function () {
  index++;
  if (index > slides.length - 1) {
    index = 0;
  }
  imgBanner.src = "./assets/images/slideshow/" + slides[index].image;
  pBanner.innerHTML = slides[index].tagLine;

  colorDotElement();

   dots = Array.from(dotsBanner.children);
   dots.forEach((dot) => dot.classList.remove("active"));
   dots[index].classList.add("active");
});

leftArrow.addEventListener("click", function () {
  index--;
  if (index < 0) {
    index = slides.length - 1;
  }
  imgBanner.src = "./assets/images/slideshow/" + slides[index].image;
  pBanner.innerHTML = slides[index].tagLine;

  colorDotElement();

  dots = Array.from(dotsBanner.children);
  dots.forEach((dot) => dot.classList.remove("active"));
  dots[index].classList.add("active");
});

// Clique sur les dots //

 dotsBanner.addEventListener("click", function (oEvent) {
   index--;
  if (oEvent.target.classList.contains("dot")) {
     dots = Array.from(dotsBanner.children);
     clickedIndex = dots.indexOf(oEvent.target);

     if (clickedIndex !== -1) {
       index = clickedIndex;
       imgBanner.src = "./assets/images/slideshow/" + slides[index].image;
       pBanner.innerHTML = slides[index].tagLine;

       dots.forEach((dot) => dot.classList.remove("active"));
      dots[clickedIndex].classList.add("active");
    }
   }
   });
